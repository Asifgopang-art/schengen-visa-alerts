package com.schengenvisaalerts.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
